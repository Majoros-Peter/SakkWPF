﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Sakk;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        RajzolTabla();
        Lerak(Directory.GetCurrentDirectory().Substring(0, Directory.GetCurrentDirectory().Length-24)+"Babuk.txt");
    }

    private void RajzolTabla()
    {
        Border bdTemp;
        TextBlock tbTemp;

        for (byte x = 0; x < 8; x++)
            for (byte y = 0; y < 8; y++)
            {
                if(x % 2 == 0 && y % 2 == 1 || x % 2 == 1 && y % 2 == 0)
                    bdTemp = new Border() { Background = Brushes.Beige };
                else
                    bdTemp = new Border() { Background = Brushes.SaddleBrown };
                Grid.SetColumn(bdTemp, x);
                Grid.SetRow(bdTemp, y);
                Tabla.Children.Add(bdTemp);
            }

    }
    private void Lerak(string path)
    {
        string[] sorok = File.ReadAllLines(path);
        byte[,] babuk = { { 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0 } };

        foreach(string sor in sorok)
        {
            if (sor[0] == '*')
                LerakSor(sor, ref babuk);
            else
            {
                string name = (sor[1]=='R' ? "Rook" : sor[1] == 'H' ? "Horse" : sor[1] == 'B' ? "Bishop" : sor[1] == 'K' ? "King" : sor[1] == 'Q' ? "Queen" : "Pawn"),
                       color = sor[0] == 'B' ? "black" : "white";

                Image babu = new()
                {
                    Name = SetName(sor.Substring(0, 2), ref babuk),
                    Height = 50,
                    Width = 50,
                    Source = new BitmapImage(new Uri($"Images/{color}/{name}.png", UriKind.Relative)),
                };

                switch (sor[1])
                {
                    case 'R':
                        babu.MouseDown += new MouseButtonEventHandler(Rook_MouseDown);
                        break;
                    case 'H':
                        babu.MouseDown += new MouseButtonEventHandler(Horse_MouseDown);
                        break;
                    case 'B':
                        babu.MouseDown += new MouseButtonEventHandler(Bishop_MouseDown);
                        break;
                    case 'K':
                        babu.MouseDown += new MouseButtonEventHandler(King_MouseDown);
                        break;
                    case 'Q':
                        babu.MouseDown += new MouseButtonEventHandler(Queen_MouseDown);
                        break;
                    case 'P':
                        if (sor[0] == 'B')
                            babu.MouseDown += sor[0] == 'B' ? new MouseButtonEventHandler(BPawn_MouseDown) : new MouseButtonEventHandler(WPawn_MouseDown);
                        break;
                    default:
                        break;
                }

                Grid.SetColumn(babu, "ABCDEFGH".IndexOf(sor[2]));
                Grid.SetRow(babu, 8-(sor[3]-48));

                Tabla.Children.Add(babu);
            }
        }
    }
    private void LerakSor(string sor, ref byte[,] babuk)
    {
        for(byte col = 0; col < 8; col++)
        {
            string name = (sor[2]=='R' ? "Rook" : sor[2] == 'H' ? "Horse" : sor[2] == 'B' ? "Bishop" : sor[2] == 'K' ? "King" : sor[2] == 'Q' ? "Queen" : "Pawn"),
                   color = sor[1] == 'B' ? "black" : "white";

            Image babu = new()
            {
                Name = SetName(sor.Substring(1, 2), ref babuk),
                Height = 50,
                Width = 50,
                Source = new BitmapImage(new Uri($"Images/{color}/{name}.png", UriKind.Relative))
            };

            switch (sor[1])
            {
                case 'R':
                    babu.MouseDown += new MouseButtonEventHandler(Rook_MouseDown);
                    break;
                case 'H':
                    babu.MouseDown += new MouseButtonEventHandler(Horse_MouseDown);
                    break;
                case 'B':
                    babu.MouseDown += new MouseButtonEventHandler(Bishop_MouseDown);
                    break;
                case 'K':
                    babu.MouseDown += new MouseButtonEventHandler(King_MouseDown);
                    break;
                case 'Q':
                    babu.MouseDown += new MouseButtonEventHandler(Queen_MouseDown);
                    break;
                case 'P':
                    if (sor[0] == 'B')
                        babu.MouseDown += sor[0] == 'B' ? new MouseButtonEventHandler(BPawn_MouseDown) : new MouseButtonEventHandler(WPawn_MouseDown);
                    break;
                default:
                    break;
            }

            Grid.SetColumn(babu, col);
            Grid.SetRow(babu, 8-(sor[3]-48));

            Tabla.Children.Add(babu);
        }
    }

    private static string SetName(string _name, ref byte[,] babuk)
    {
        byte index = _name[0]=='B' ? (byte)0 : (byte)1;

        return _name[1] switch
        {
            'R' => $"{_name[0]}Rook{babuk[index, 0]++}",
            'H' => $"{_name[0]}Horse{babuk[index, 1]++}",
            'B' => $"{_name[0]}Bishop{babuk[index, 2]++}",
            'K' => $"{_name[0]}King{babuk[index, 3]++}",
            'Q' => $"{_name[0]}Queen{babuk[index, 4]++}",
            'P' => $"{_name[0]}Pawn{babuk[index, 5]++}",
            _ => "Baj van!",
        };
    }
    private Image? GetBabu(string nev)
    {
        foreach (Image babu in Tabla.Children)
            if (babu.Name == nev)
                return babu;
        return null;
    }
    

    private void Rook_MouseDown(object sender, MouseButtonEventArgs e)
    {
        GetBabu("BRook0").Source = new BitmapImage(new Uri("Images/black/Pawn.png", UriKind.Relative));
    }
    private void Horse_MouseDown(object sender, MouseButtonEventArgs e)
    {
        return;
    }
    private void Bishop_MouseDown(object sender, MouseButtonEventArgs e)
    {
        return;
    }
    private void King_MouseDown(object sender, MouseButtonEventArgs e)
    {
        return;
    }
    private void Queen_MouseDown(object sender, MouseButtonEventArgs e)
    {
        return;
    }
    private void BPawn_MouseDown(object sender, MouseButtonEventArgs e)
    {
        return;
    }
    private void WPawn_MouseDown(object sender, MouseButtonEventArgs e)
    {
        return;
    }
}