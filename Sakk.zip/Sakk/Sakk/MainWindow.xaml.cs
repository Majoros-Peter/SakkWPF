﻿using System.Windows;

namespace Sakk;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void btnJatek_Click(object sender, RoutedEventArgs e)
    {
        SakkTabla jatek = new();
        jatek.Show();
        this.Close();
    }

    private void btnKilepes_Click(object sender, RoutedEventArgs e)
    {
        this.Close();
    }

    private void btnBeallitasok_Click(object sender, RoutedEventArgs e)
    {
        Beallitasok beallitasok = new();
        beallitasok.Show();
        this.Close();
    }
}