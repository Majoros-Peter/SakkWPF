﻿using System.Windows;

namespace Sakk;

/// <summary>
/// Interaction logic for Beallitasok.xaml
/// </summary>
public partial class Beallitasok : Window
{
    public Beallitasok()
    {
        InitializeComponent();
    }

    private void btnVissza_Click(object sender, RoutedEventArgs e)
    {
        MainWindow fomenu = new();
        fomenu.Show();
        this.Close();
    }
}
